import Button from '@mui/material/Button';

const Button = () => {
  return <Button>버튼</Button>;
};

export default Button;
