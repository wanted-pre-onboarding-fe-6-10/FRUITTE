const Nav = () => {
  return <>Nav</>;
};

export default Nav;
