const Title = () => {
  return <>Title</>;
};

export default Title;
