const Input = () => {
  return <>Input</>;
};

export default Input;
