import OrderItem from './components/OrderItem';

const Order = () => {
  return (
    <Container>
      <OrderItem />
    </Container>
  );
};

// styled-components 위치

export default Order;
